package io.github.solclient.client.event.impl;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class PreGuiRenderEvent {

	public final float partialTicks;

}
