package io.github.solclient.client.event.impl;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class FovEvent {

	public float fov;
	public final float partialTicks;

}
