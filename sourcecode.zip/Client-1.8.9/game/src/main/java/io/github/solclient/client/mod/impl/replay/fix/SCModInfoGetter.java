package io.github.solclient.client.mod.impl.replay.fix;

import java.util.Collection;
import java.util.Collections;

import com.replaymod.replaystudio.data.ModInfo;

public class SCModInfoGetter {

	public static Collection<ModInfo> getInstalledNetworkMods() {
		return Collections.emptyList();
	}

}
