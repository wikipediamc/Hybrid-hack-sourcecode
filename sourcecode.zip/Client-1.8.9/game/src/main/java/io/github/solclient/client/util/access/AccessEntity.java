package io.github.solclient.client.util.access;

public interface AccessEntity {

	boolean getIsInWeb();

}
