package io.github.solclient.client.event.impl;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class HitOverlayEvent {

	public float r;
	public float g;
	public float b;
	public float a;

}
