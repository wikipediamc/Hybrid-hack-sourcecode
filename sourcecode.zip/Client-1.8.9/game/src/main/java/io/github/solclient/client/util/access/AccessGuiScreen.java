package io.github.solclient.client.util.access;

public interface AccessGuiScreen {

	boolean canBeForceClosed();

}
