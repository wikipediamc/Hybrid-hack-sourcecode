package io.github.solclient.client.util.access;

public interface AccessGuiMainMenu {

	void renderPanorama(int mouseX, int mouseY, float partialTicks);

	void rotateAndBlurPanorama(float partialTicks);

}
