package io.github.solclient.client.util.access;

public interface AccessEntityLivingBase {

	int accessArmSwingAnimationEnd();

}
