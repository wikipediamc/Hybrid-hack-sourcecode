package io.github.solclient.client.event.impl;

import lombok.AllArgsConstructor;
import net.minecraft.client.gui.GuiScreen;

@AllArgsConstructor
public class InitialOpenGuiEvent {

	public final GuiScreen screen;

}
