package io.github.solclient.client.mod;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class CommandHotkey {

	public int key;
	public String action;

}
