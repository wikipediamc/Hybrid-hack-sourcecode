package io.github.solclient.client.util.access;

import java.util.List;

import net.minecraft.client.shader.Shader;

public interface AccessShaderGroup {

	List<Shader> getListShaders();

}
