package io.github.solclient.client.event.impl;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class PostGuiRenderEvent {

	public final float partialTicks;

}
