package io.github.solclient.client.event.impl;

/**
 * Tick event (empty event).
 */
public class PreTickEvent {
}
