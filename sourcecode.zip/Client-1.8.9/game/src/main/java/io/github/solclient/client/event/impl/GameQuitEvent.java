package io.github.solclient.client.event.impl;

public class GameQuitEvent {
}
