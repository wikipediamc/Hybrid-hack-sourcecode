package io.github.solclient.client.culling;

public interface Cullable {

	boolean isCulled();

	void setCulled(boolean culled);

}
