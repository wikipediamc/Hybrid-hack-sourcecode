package io.github.solclient.client.mod;

public interface PrimaryIntegerSettingMod {

	void increment();

	void decrement();

}
