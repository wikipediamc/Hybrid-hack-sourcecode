package io.github.solclient.client.util;

/**
 * Replaces any classes not on the classpath, that do not need any body.
 */
public class Stub {
}
