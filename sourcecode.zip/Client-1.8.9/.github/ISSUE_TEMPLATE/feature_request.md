---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: enhancement
assignees: ''

---

## Problem
If this feature is related to a problem, please describe here. For example, I'm always frustrated when [...]

## Solution
A clear and concise description of what you want to happen.

## Alternative Solutions
Any alternative solutions or features you've considered.

## Additional context
Add any other context or screenshots about the feature request here.
